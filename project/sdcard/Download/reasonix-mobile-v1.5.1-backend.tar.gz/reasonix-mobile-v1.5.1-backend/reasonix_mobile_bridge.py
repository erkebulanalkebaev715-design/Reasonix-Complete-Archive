#!/usr/bin/env python3
"""Reasonix Mobile v1 loopback bridge/supervisor.

No agent logic lives here. This process only:
- owns/restarts the existing `reasonix serve` child,
- authenticates to it with the supervisor token,
- exposes a CORS-safe loopback facade for the APK WebView,
- lists/switches configured Reasonix models,
- writes user-created native Reasonix project skills under .reasonix/skills.
"""
from __future__ import annotations
import argparse, atexit, hmac, http.cookiejar, json, os, re, signal, subprocess, sys, threading, time
import urllib.error, urllib.request
import tomllib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

MAX_BODY = 4 * 1024 * 1024
SKILL_MAX = 128 * 1024
SAFE_SKILL = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$')
SAFE_MCP = re.compile(r'^[A-Za-z_][A-Za-z0-9_-]{0,63}$')
BRIDGE_VERSION = 'reasonix-mobile-v1.5.1'

def atomic_write(path: Path, data: bytes, mode: int | None = None):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.tmp.{os.getpid()}.{threading.get_ident()}')
    try:
        with open(tmp, 'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        if mode is not None: os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass


class MobileCore:
    def __init__(self, root: str, binary: str, state: str, token_file: str, model: str):
        self.root = Path(root).resolve(); self.binary = str(Path(binary).resolve()); self.state = Path(state).resolve()
        self.token_file = Path(token_file).resolve(); self.token = self.token_file.read_text(encoding='utf-8').strip()
        self.model_file = self.state / 'model'; self.up_port = self.state / 'reasonix.port'; self.up_pid = self.state / 'reasonix.pid'; self.up_log = self.state / 'reasonix.log'
        self.lock = threading.RLock(); self.proc: subprocess.Popen | None = None; self.upstream = ''; self.jar = None; self.opener = None
        persisted = self.model_file.read_text(encoding='utf-8').strip() if self.model_file.exists() else ''
        self.model = persisted or model
        self.env = os.environ.copy(); self.env['PATH'] = '/usr/local/go/bin:' + self.env.get('PATH','/usr/bin:/bin'); self.env['GOTOOLCHAIN'] = 'local'
        self.start_upstream(self.model)
        atexit.register(self.stop_upstream)

    def _read(self,p):
        try:return Path(p).read_text(encoding='utf-8').strip()
        except Exception:return ''

    def start_upstream(self, model: str):
        with self.lock:
            self.stop_upstream()
            for p in (self.up_port,self.up_pid):
                try:p.unlink()
                except FileNotFoundError:pass
            log = open(self.up_log,'ab', buffering=0)
            args=[self.binary,'serve','--model',model,'--addr','127.0.0.1:0','--auth','token','--port-file',str(self.up_port),'--token-file',str(self.token_file),'--pid-file',str(self.up_pid)]
            try:
                self.proc=subprocess.Popen(args,cwd=self.root,env=self.env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            finally:
                # Child inherited the fd; parent must not leak one descriptor per restart.
                log.close()
            deadline=time.time()+25
            while time.time()<deadline:
                if self.proc.poll() is not None: raise RuntimeError(f'reasonix serve exited rc={self.proc.returncode}; see {self.up_log}')
                if self.up_port.exists() and self.up_pid.exists() and self._read(self.up_port): break
                time.sleep(.1)
            addr=self._read(self.up_port)
            if not addr.startswith('127.0.0.1:'):
                self.stop_upstream(); raise RuntimeError(f'bad/non-loopback reasonix address: {addr!r}')
            self.upstream='http://'+addr
            self.jar=http.cookiejar.CookieJar(); self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
            self._bootstrap_auth()
            # Prove the selected model actually produced a live backend before committing it.
            code,_,_=self._request_upstream('GET','/mod/status',b'',None,timeout=8)
            if code!=200:
                self.stop_upstream(); raise RuntimeError(f'reasonix status HTTP {code}')
            self.model=model; atomic_write(self.model_file,(model+'\n').encode('utf-8'),0o600)

    def stop_upstream(self):
        with self.lock:
            p=self.proc; self.proc=None
            if p and p.poll() is None:
                # `start_new_session=True` makes p.pid the process-group id. Stop the
                # whole serve group so helper descendants cannot survive a restart.
                try: os.killpg(p.pid, signal.SIGTERM)
                except Exception:
                    try: p.terminate()
                    except Exception: pass
                try: p.wait(timeout=5)
                except Exception:
                    try: os.killpg(p.pid, signal.SIGKILL)
                    except Exception:
                        try: p.kill()
                        except Exception: pass
                    try: p.wait(timeout=2)
                    except Exception: pass
            # Only use a pid-file fallback when it still clearly names this Reasonix
            # serve process; never kill an arbitrary process after PID reuse.
            pid=self._read(self.up_pid)
            if pid.isdigit() and (not p or int(pid)!=p.pid):
                proc=Path('/proc')/pid/'cmdline'
                try: cmd=proc.read_bytes().replace(b'\0',b' ').decode('utf-8','replace')
                except Exception: cmd=''
                if self.binary in cmd and ' serve ' in (' '+cmd+' '):
                    try: os.kill(int(pid),signal.SIGTERM)
                    except Exception: pass
            for f in (self.up_port,self.up_pid):
                try:f.unlink()
                except FileNotFoundError:pass

    def _bootstrap_auth(self):
        data=json.dumps({'token':self.token}).encode()
        req=urllib.request.Request(self.upstream+'/auth/token',data=data,headers={'Content-Type':'application/json'},method='POST')
        with self.opener.open(req,timeout=8) as r:
            if r.status!=204: raise RuntimeError(f'upstream auth HTTP {r.status}')

    def _request_upstream(self,method,path,body,ctype,timeout=65,upstream=None,opener=None):
        upstream = upstream or self.upstream; opener = opener or self.opener
        headers={'Accept':'application/json, text/plain, */*'}
        if ctype:headers['Content-Type']=ctype
        req=urllib.request.Request(upstream+path,data=body if method!='GET' else None,headers=headers,method=method)
        try:
            with opener.open(req,timeout=timeout) as r:
                out=r.read(MAX_BODY+1)
                if len(out)>MAX_BODY:return 502,{'Content-Type':'text/plain'},b'Upstream response too large\n'
                return r.status,{'Content-Type':r.headers.get('Content-Type','application/octet-stream'),'Cache-Control':'no-store'},out
        except urllib.error.HTTPError as e:
            out=e.read(MAX_BODY+1)
            return e.code,{'Content-Type':e.headers.get('Content-Type','text/plain; charset=utf-8'),'Cache-Control':'no-store'},out[:MAX_BODY]

    CONTROL_ROUTES={'/approve','/answer','/tool-approval-mode','/plan'}

    @staticmethod
    def _event_list(doc):
        if isinstance(doc,list): return doc
        if isinstance(doc,dict):
            for key in ('events','history','items'):
                if isinstance(doc.get(key),list): return doc[key]
        return []

    @staticmethod
    def _reasoning_text(obj):
        if not isinstance(obj,dict): return ''
        for key in ('reasoning','reasoning_content','reasoningContent','thinking'):
            v=obj.get(key)
            if isinstance(v,str) and v.strip(): return v.strip()
        data=obj.get('data')
        if isinstance(data,dict):
            for key in ('reasoning','reasoning_content','reasoningContent','thinking'):
                v=data.get(key)
                if isinstance(v,str) and v.strip(): return v.strip()
        return ''

    @staticmethod
    def _message_text(obj):
        if not isinstance(obj,dict): return ''
        for key in ('text','content','message'):
            v=obj.get(key)
            if isinstance(v,str) and v.strip(): return v.strip()
        data=obj.get('data')
        if isinstance(data,dict):
            for key in ('text','content','message'):
                v=data.get(key)
                if isinstance(v,str) and v.strip(): return v.strip()
        return ''

    def _history_latest_assistant(self, upstream, opener):
        try:
            code,_,raw=self._request_upstream('GET','/history',b'',None,timeout=8,upstream=upstream,opener=opener)
            if code!=200: return None
            doc=json.loads(raw.decode('utf-8','replace') or '[]')
        except Exception:
            return None
        items=self._event_list(doc)
        if not items and isinstance(doc,dict):
            for key in ('messages','history','items'):
                if isinstance(doc.get(key),list): items=doc[key]; break
        for item in reversed(items):
            if not isinstance(item,dict): continue
            role=str(item.get('role') or (item.get('data') or {}).get('role') or '').lower()
            if role not in ('assistant','ai'): continue
            reasoning=self._reasoning_text(item)
            if reasoning:
                return {'reasoning':reasoning,'text':self._message_text(item)}
        return None

    def _augment_live_history(self,status,headers,raw,upstream,opener):
        # Preserve native live Reasoning events untouched. Only after a completed
        # turn, if Balance live-history omitted reasoning, recover the exact
        # provider-visible reasoning already persisted by Reasonix /history.
        if status!=200: return status,headers,raw
        try: doc=json.loads(raw.decode('utf-8','replace') or '{}')
        except Exception: return status,headers,raw
        events=self._event_list(doc)
        if not events: return status,headers,raw
        def typ(e): return str((e or {}).get('type') or (e or {}).get('kind') or '').lower() if isinstance(e,dict) else ''
        if any(self._reasoning_text(e) or any(x in typ(e) for x in ('reason','think','analysis')) for e in events):
            return status,headers,raw
        done=[e for e in events if typ(e)=='live.turn.done']
        messages=[e for e in events if typ(e)=='live.chat.message' and self._message_text(e)]
        if not done or not messages: return status,headers,raw
        hist=self._history_latest_assistant(upstream,opener)
        if not hist or not hist.get('reasoning'): return status,headers,raw
        # Refuse to attach reasoning from an older turn. Require the latest
        # persisted assistant answer to agree with the latest live answer when
        # both texts are available.
        live_text=self._message_text(messages[-1]).strip()
        hist_text=str(hist.get('text') or '').strip()
        if live_text and hist_text:
            a=re.sub(r'\s+',' ',live_text)[:240]
            b=re.sub(r'\s+',' ',hist_text)[:240]
            if a!=b and a not in b and b not in a:
                return status,headers,raw
        max_seq=max([int(e.get('sequence',e.get('seq',-1))) for e in events if isinstance(e,dict) and str(e.get('sequence',e.get('seq','-1'))).lstrip('-').isdigit()] or [-1])
        synthetic={'type':'reasoning.history','sequence':max_seq+1,'data':{'reasoning':hist['reasoning'],'source':'reasonix-history','syntheticTransportFallback':True}}
        events.append(synthetic)
        out=json.dumps(doc,ensure_ascii=False).encode('utf-8')
        headers=dict(headers); headers['Content-Type']='application/json'; headers['Content-Length']=str(len(out))
        return status,headers,out

    def forward(self,method,path,body,ctype):
        clean=path.split('?',1)[0]
        if not (path.startswith('/mod/') or clean in self.CONTROL_ROUTES):return 404,{'Content-Type':'text/plain'},b'Not Found\n'
        if clean in self.CONTROL_ROUTES and method!='POST':return 405,{'Content-Type':'text/plain'},b'Method Not Allowed\n'
        # Hold the lifecycle lock only long enough to snapshot one consistent
        # upstream generation. A stalled provider request must not freeze every
        # health/status/mobile endpoint for up to 65 seconds.
        with self.lock:
            if not self.proc or self.proc.poll() is not None:return 503,{'Content-Type':'text/plain'},b'Reasonix backend stopped\n'
            upstream,opener=self.upstream,self.opener
        result=self._request_upstream(method,path,body,ctype,upstream=upstream,opener=opener)
        if method=='GET' and clean=='/mod/live/history':
            return self._augment_live_history(*result,upstream,opener)
        return result

    def doctor(self):
        cp=subprocess.run([self.binary,'doctor','--json'],cwd=self.root,env=self.env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=25)
        if cp.returncode!=0:raise RuntimeError((cp.stderr or cp.stdout or 'doctor failed')[-2000:])
        return json.loads(cp.stdout)

    def models(self):
        d=self.doctor(); raw=[]
        for p in d.get('providers',[]) or []:
            name=str(p.get('name','')).strip(); kind=str(p.get('kind','')); ready=bool(p.get('key_present',False) or kind=='mock')
            ms=p.get('models') or ([p.get('model')] if p.get('model') else [])
            for m in ms:
                if name and m: raw.append({'ref':f'{name}/{m}','provider':name,'model':str(m),'kind':kind,'ready':ready,'default':bool(p.get('is_default',False))})
        # UI should not show three identical Flash entries. Prefer current, then ready, then default.
        groups={}
        for x in raw: groups.setdefault(x['model'].lower(),[]).append(x)
        out=[]
        for _,xs in groups.items():
            xs.sort(key=lambda x:(x['ref']!=self.model, not x['ready'], not x['default'], x['provider']))
            best=dict(xs[0]);best['alternatives']=[z['ref'] for z in xs[1:]];best['duplicateCount']=len(xs)
            if not best['ready']:
                ready_alt=next((z for z in xs if z['ready']),None)
                if ready_alt:
                    best=dict(ready_alt);best['alternatives']=[z['ref'] for z in xs if z['ref']!=ready_alt['ref']];best['duplicateCount']=len(xs)
            out.append(best)
        out.sort(key=lambda x:(x['ref']!=self.model, not x['ready'], x['model']))
        return {'current':self.model,'models':out,'rawModels':raw}

    def switch_model(self,ref):
        with self.lock:
            avail={x['ref']:x for x in self.models()['models']}
            if ref not in avail:raise ValueError('model ref not configured in Reasonix')
            if not avail[ref]['ready']:raise ValueError('provider is not ready')
            old=self.model
            if ref==old:return {'ok':True,'model':ref,'changed':False}
            try:self.start_upstream(ref)
            except Exception as e:
                try:self.start_upstream(old)
                except Exception:pass
                raise RuntimeError(f'model switch failed; rollback attempted: {e}')
            return {'ok':True,'model':ref,'changed':True}

    def add_provider(self,obj):
        name=str(obj.get('name','')).strip();kind=str(obj.get('kind','openai')).strip().lower();base=str(obj.get('baseUrl','')).strip().rstrip('/')
        models=obj.get('models') or []; env_name=str(obj.get('apiKeyEnv','')).strip(); key=str(obj.get('apiKey',''))
        try:ctx=int(obj.get('contextWindow') or 128000)
        except Exception:raise ValueError('bad contextWindow')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,47}',name):raise ValueError('provider name: letters/numbers/_/-, max 48')
        if kind not in ('openai','anthropic'):raise ValueError('kind must be openai|anthropic')
        if not (base.startswith('https://') or base.startswith('http://127.0.0.1') or base.startswith('http://localhost')):raise ValueError('baseUrl must be https:// or local loopback http://')
        if isinstance(models,str):models=[x.strip() for x in models.split(',') if x.strip()]
        if not isinstance(models,list) or not models:raise ValueError('at least one model required')
        models=[str(x).strip() for x in models if str(x).strip()]
        if not models or len(models)>32 or any(len(x)>160 or any(c in x for c in '\r\n"') for x in models):raise ValueError('invalid model list')
        if not env_name:env_name=re.sub(r'[^A-Za-z0-9_]','_',name.upper())+'_API_KEY'
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,127}',env_name):raise ValueError('invalid API key variable name')
        if ctx<4096 or ctx>4000000:raise ValueError('contextWindow out of range')
        cfg=self.root/'reasonix.toml'; old_cfg=cfg.read_bytes() if cfg.exists() else b''
        try: parsed=tomllib.loads(old_cfg.decode('utf-8')) if old_cfg else {}
        except Exception as e:raise ValueError(f'existing reasonix.toml is invalid: {e}')
        if any(str(x.get('name',''))==name for x in (parsed.get('providers') or [])):raise ValueError('provider already exists')
        import json as _json
        block=['','[[providers]]',f'name = {_json.dumps(name)}',f'kind = {_json.dumps(kind)}',f'base_url = {_json.dumps(base)}',
               'models = ['+', '.join(_json.dumps(x) for x in models)+']',f'default = {_json.dumps(models[0])}',f'api_key_env = {_json.dumps(env_name)}',f'context_window = {ctx}','']
        atomic_write(cfg,(old_cfg.decode('utf-8')+'\n'.join(block)).encode('utf-8'))
        env_path=Path(os.environ.get('REASONIX_HOME') or (Path.home()/'.reasonix'))/'.env'; env_path.parent.mkdir(parents=True,exist_ok=True)
        old_env=env_path.read_bytes() if env_path.exists() else None
        try:
            if key:
                if '\n' in key or '\r' in key:raise ValueError('API key contains newline')
                lines=env_path.read_text(encoding='utf-8').splitlines() if env_path.exists() else []; out=[];done=False
                for line in lines:
                    if line.startswith(env_name+'='):out.append(env_name+'='+key);done=True
                    else:out.append(line)
                if not done:out.append(env_name+'='+key)
                atomic_write(env_path,('\n'.join(out)+'\n').encode('utf-8'),0o600)
            self.doctor()
        except Exception:
            atomic_write(cfg,old_cfg)
            if old_env is None:
                try:env_path.unlink()
                except FileNotFoundError:pass
            else:atomic_write(env_path,old_env,0o600)
            raise
        return {'ok':True,'provider':name,'models':[f'{name}/{m}' for m in models],'apiKeyEnv':env_name,'keyStored':bool(key)}

    @property
    def projects_path(self):
        return self.state / 'projects.json'

    def _load_projects(self):
        if not self.projects_path.exists():
            return {'version':1,'projects':[]}
        try:
            doc=json.loads(self.projects_path.read_text(encoding='utf-8'))
        except Exception as e:
            raise ValueError(f'projects.json is invalid: {e}')
        if not isinstance(doc,dict) or not isinstance(doc.get('projects',[]),list):
            raise ValueError('projects.json schema is invalid')
        doc.setdefault('version',1)
        return doc

    @staticmethod
    def _project_item(obj, existing=None):
        if not isinstance(obj,dict): raise ValueError('project must be an object')
        pid=str(obj.get('id') or (existing or {}).get('id') or '').strip()
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,95}',pid): raise ValueError('bad project id')
        name=str(obj.get('name') if 'name' in obj else (existing or {}).get('name','')).strip()
        if not name or len(name)>120 or any(c in name for c in '\r\n\0'): raise ValueError('bad project name')
        workspace=str(obj.get('workspace',obj.get('path',(existing or {}).get('workspace','')))).strip()
        if len(workspace)>4096 or any(c in workspace for c in '\r\n\0'): raise ValueError('bad workspace')
        def norm_refs(value, key, max_items):
            if value is None: value=(existing or {}).get(key,[])
            if not isinstance(value,list) or len(value)>max_items: raise ValueError(f'bad {key}')
            out=[]
            for x in value:
                if isinstance(x,str): x={'value':x}
                if not isinstance(x,dict): raise ValueError(f'bad {key} item')
                val=str(x.get('url') or x.get('path') or x.get('value') or '').strip()
                label=str(x.get('label') or val).strip()[:240]
                if not val or len(val)>8192 or any(c in val for c in '\r\n\0'): raise ValueError(f'bad {key} item')
                if key=='sources': out.append({'url':val,'label':label})
                else: out.append({'path':val,'label':label})
            return out
        sources=norm_refs(obj.get('sources'), 'sources', 128)
        files=norm_refs(obj.get('files'), 'files', 512)
        chats=obj.get('chatIds',(existing or {}).get('chatIds',[]))
        if not isinstance(chats,list) or len(chats)>1024: raise ValueError('bad chatIds')
        chat_ids=[]
        for x in chats:
            x=str(x).strip()
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}',x): raise ValueError('bad chat id')
            if x not in chat_ids: chat_ids.append(x)
        created=int((existing or {}).get('created') or obj.get('created') or int(time.time()*1000))
        return {'id':pid,'name':name,'workspace':workspace,'sources':sources,'files':files,'chatIds':chat_ids,'created':created,'updated':int(time.time()*1000)}

    def list_projects(self):
        doc=self._load_projects()
        return {'projects':doc.get('projects',[]),'path':str(self.projects_path)}

    def save_project(self,obj):
        doc=self._load_projects(); items=doc.setdefault('projects',[])
        pid=str((obj or {}).get('id','')).strip()
        old=next((x for x in items if isinstance(x,dict) and x.get('id')==pid),None) if pid else None
        if not pid:
            pid='p'+str(int(time.time()*1000))+'-'+os.urandom(4).hex()
            obj=dict(obj or {}); obj['id']=pid
        item=self._project_item(obj,old)
        replaced=False
        for i,x in enumerate(items):
            if isinstance(x,dict) and x.get('id')==item['id']:
                items[i]=item;replaced=True;break
        if not replaced: items.insert(0,item)
        atomic_write(self.projects_path,(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),0o600)
        return {'ok':True,'project':item,'created':not replaced}

    def delete_project(self,pid):
        pid=str(pid or '').strip()
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,95}',pid): raise ValueError('bad project id')
        doc=self._load_projects(); old=doc.get('projects',[]); new=[x for x in old if not (isinstance(x,dict) and x.get('id')==pid)]
        doc['projects']=new
        atomic_write(self.projects_path,(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),0o600)
        return {'ok':True,'id':pid,'deleted':len(new)!=len(old)}

    def get_system_prompt(self):
        cfg=self.root/'reasonix.toml'
        if not cfg.exists():return {'prompt':'','source':'project','path':str(cfg),'exists':False}
        try:doc=tomllib.loads(cfg.read_text(encoding='utf-8'))
        except Exception as e:raise ValueError(f'reasonix.toml parse failed: {e}')
        agent=doc.get('agent') or {}
        return {'prompt':str(agent.get('system_prompt') or ''),'source':'project','path':str(cfg),'exists':bool(agent.get('system_prompt'))}

    def set_system_prompt(self,obj):
        prompt=str(obj.get('prompt',''))
        if len(prompt.encode('utf-8'))>128*1024:raise ValueError('system prompt too large')
        cfg=self.root/'reasonix.toml'
        old=cfg.read_bytes() if cfg.exists() else b''
        text=old.decode('utf-8') if old else ''
        # Keep edits local to [agent] and preserve the rest of the user's TOML.
        m=re.search(r'(?m)^\[agent\]\s*(?:#.*)?$',text)
        encoded=json.dumps(prompt,ensure_ascii=False)
        if m:
            start=m.end(); nxt=re.search(r'(?m)^\s*\[',text[start:]); end=start+(nxt.start() if nxt else len(text[start:]))
            block=text[start:end]
            # v1.2 manages a single-line TOML basic string. Refuse to mangle a hand-authored multiline value.
            if re.search(r'(?m)^[ \t]*system_prompt[ \t]*=[ \t]*[\"\']{3}',block):
                raise ValueError('existing multiline system_prompt must be edited manually')
            if re.search(r'(?m)^[ \t]*system_prompt[ \t]*=',block):
                if prompt:block=re.sub(r'(?m)^[ \t]*system_prompt[ \t]*=.*$',f'system_prompt = {encoded}',block,count=1)
                else:block=re.sub(r'(?m)^[ \t]*system_prompt[ \t]*=.*(?:\n|$)','',block,count=1)
            elif prompt:
                block='\nsystem_prompt = '+encoded+block
            new=text[:start]+block+text[end:]
        else:
            new=text.rstrip()+('\n\n' if text.strip() else '')+'[agent]\n'+(('system_prompt = '+encoded+'\n') if prompt else '')
        try:
            tomllib.loads(new)
            atomic_write(cfg,new.encode('utf-8'))
            self.doctor()
            self.start_upstream(self.model)
        except Exception:
            if old:atomic_write(cfg,old)
            else:
                try:cfg.unlink()
                except FileNotFoundError:pass
            try:self.start_upstream(self.model)
            except Exception:pass
            raise
        return {'ok':True,'prompt':prompt,'reloaded':True,'source':'project'}

    @property
    def skills_root(self):return self.root/'.reasonix'/'skills'
    def list_skills(self):
        root=self.skills_root; items=[]
        if root.exists():
            for f in sorted(root.glob('*/SKILL.md')):
                txt=f.read_text(encoding='utf-8',errors='replace');desc=''
                m=re.search(r'(?m)^description:\s*["\']?(.*?)["\']?\s*$',txt)
                if m:desc=m.group(1)
                items.append({'name':f.parent.name,'description':desc,'path':str(f.relative_to(self.root)),'enabled':True})
            for f in sorted(root.glob('*.md')):
                items.append({'name':f.stem,'description':'','path':str(f.relative_to(self.root)),'enabled':True})
        if self.disabled_skills_root.exists():
            for f in sorted(self.disabled_skills_root.glob('*/SKILL.md')):
                txt=f.read_text(encoding='utf-8',errors='replace');desc=''
                m=re.search(r'(?m)^description:\s*["\']?(.*?)["\']?\s*$',txt)
                if m:desc=m.group(1)
                items.append({'name':f.parent.name,'description':desc,'path':str(f),'enabled':False})
        return {'skills':items}
    def save_skill(self,obj):
        name=str(obj.get('name','')).strip(); body=str(obj.get('body','')).strip(); desc=str(obj.get('description','')).strip()[:240]
        run_as=str(obj.get('runAs','inline')).strip(); invocation=str(obj.get('invocation','auto')).strip()
        if not SAFE_SKILL.fullmatch(name):raise ValueError('skill name: letters/numbers/_/-, max 64')
        if not body:raise ValueError('skill body is empty')
        if len(body.encode())>SKILL_MAX:raise ValueError('skill body too large')
        if run_as not in ('inline','subagent'):raise ValueError('runAs must be inline|subagent')
        if invocation not in ('auto','manual'):raise ValueError('invocation must be auto|manual')
        if not desc:desc=f'User skill {name}'
        allowed=obj.get('allowedTools') or []
        if not isinstance(allowed,list):allowed=[]
        allowed=[str(x).strip() for x in allowed if str(x).strip()][:64]
        fm=['---',f'name: {name}',f'description: {json.dumps(desc,ensure_ascii=False)}',f'runAs: {run_as}',f'invocation: {invocation}']
        if allowed:fm.append('allowed-tools: ['+', '.join(json.dumps(x) for x in allowed)+']')
        fm+=['---','',body,'']
        dest=self.skills_root/name/'SKILL.md';dest.parent.mkdir(parents=True,exist_ok=True)
        atomic_write(dest,'\n'.join(fm).encode('utf-8'))
        return {'ok':True,'name':name,'path':str(dest.relative_to(self.root))}
    def delete_skill(self,name):
        if not SAFE_SKILL.fullmatch(name):raise ValueError('bad skill name')
        dest=self.skills_root/name/'SKILL.md'; legacy=self.skills_root/(name+'.md'); deleted=False
        if dest.exists():dest.unlink();deleted=True
        if legacy.exists():legacy.unlink();deleted=True
        try:dest.parent.rmdir()
        except OSError:pass
        return {'ok':True,'name':name,'deleted':deleted}

    @property
    def mcp_path(self):return self.root/'.mcp.json'
    def _load_mcp_doc(self):
        if not self.mcp_path.exists():return {'mcpServers':{}}
        try:doc=json.loads(self.mcp_path.read_text(encoding='utf-8'))
        except Exception as e:raise ValueError(f'.mcp.json is invalid: {e}')
        if not isinstance(doc,dict):raise ValueError('.mcp.json root must be an object')
        servers=doc.get('mcpServers')
        if servers is None:doc['mcpServers']={}
        elif not isinstance(servers,dict):raise ValueError('.mcp.json mcpServers must be an object')
        return doc
    def list_mcp_tools(self):
        doc=self._load_mcp_doc();out=[]
        for name,spec in sorted((doc.get('mcpServers') or {}).items()):
            if not isinstance(spec,dict):continue
            transport='stdio' if spec.get('command') else str(spec.get('type') or 'remote')
            out.append({'name':name,'transport':transport,'command':str(spec.get('command') or ''),'args':spec.get('args') or [],
                        'url':str(spec.get('url') or ''),'envKeys':sorted((spec.get('env') or {}).keys()) if isinstance(spec.get('env'),dict) else [],
                        'headerKeys':sorted((spec.get('headers') or {}).keys()) if isinstance(spec.get('headers'),dict) else [],
                        'autoStart':spec.get('auto_start'),'enabled':spec.get('auto_start',True) is not False})
        return {'servers':out,'path':str(self.mcp_path.relative_to(self.root))}
    @staticmethod
    def _clean_map(v,label):
        if v in (None,''):return {}
        if not isinstance(v,dict):raise ValueError(f'{label} must be JSON object')
        if len(v)>64:raise ValueError(f'{label} has too many entries')
        out={}
        for k,val in v.items():
            k=str(k).strip(); val=str(val)
            if not k or len(k)>128 or any(c in k for c in '\r\n\0') or len(val)>8192 or any(c in val for c in '\r\n\0'):
                raise ValueError(f'invalid {label} entry')
            out[k]=val
        return out
    def save_mcp_tool(self,obj):
        name=str(obj.get('name','')).strip();transport=str(obj.get('transport','stdio')).strip().lower()
        if not SAFE_MCP.fullmatch(name):raise ValueError('tool server name: letters/numbers/_/-, max 64')
        if transport not in ('stdio','sse','http'):raise ValueError('transport must be stdio|sse|http')
        doc=self._load_mcp_doc();servers=doc.setdefault('mcpServers',{})
        if name in servers and not bool(obj.get('replace',False)):raise ValueError('tool server already exists')
        auto=bool(obj.get('autoStart',True));spec={'auto_start':auto}
        if transport=='stdio':
            cmd=str(obj.get('command','')).strip();args=obj.get('args') or []
            if not cmd or len(cmd)>1024 or any(c in cmd for c in '\r\n\0'):raise ValueError('stdio command required')
            if isinstance(args,str):args=[x for x in args.split(' ') if x]
            if not isinstance(args,list) or len(args)>128:raise ValueError('args must be an array')
            args=[str(x) for x in args]
            if any(len(x)>4096 or any(c in x for c in '\r\n\0') for x in args):raise ValueError('invalid arg')
            spec.update({'command':cmd,'args':args})
            env=self._clean_map(obj.get('env'),'env')
            if env:spec['env']=env
        else:
            url=str(obj.get('url','')).strip()
            if not (url.startswith('https://') or url.startswith('http://127.0.0.1') or url.startswith('http://localhost')):raise ValueError('remote MCP URL must be https:// or local loopback http://')
            if len(url)>4096 or any(c in url for c in '\r\n\0'):raise ValueError('invalid MCP URL')
            spec.update({'type':transport,'url':url})
            headers=self._clean_map(obj.get('headers'),'headers')
            if headers:spec['headers']=headers
        old=self.mcp_path.read_bytes() if self.mcp_path.exists() else None
        servers[name]=spec
        atomic_write(self.mcp_path,(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        try:
            self.doctor()
            self.start_upstream(self.model)
        except Exception:
            if old is None:
                try:self.mcp_path.unlink()
                except FileNotFoundError:pass
            else:atomic_write(self.mcp_path,old)
            try:self.start_upstream(self.model)
            except Exception:pass
            raise
        return {'ok':True,'name':name,'transport':transport,'reloaded':True}
    def delete_mcp_tool(self,name):
        if not SAFE_MCP.fullmatch(name):raise ValueError('bad tool server name')
        doc=self._load_mcp_doc();servers=doc.get('mcpServers') or {}
        if name not in servers:return {'ok':True,'name':name,'deleted':False}
        old=self.mcp_path.read_bytes() if self.mcp_path.exists() else None
        del servers[name];doc['mcpServers']=servers
        atomic_write(self.mcp_path,(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        try:self.doctor();self.start_upstream(self.model)
        except Exception:
            if old is not None:atomic_write(self.mcp_path,old)
            try:self.start_upstream(self.model)
            except Exception:pass
            raise
        return {'ok':True,'name':name,'deleted':True,'reloaded':True}

    @property
    def android_tools_script(self):
        return Path(__file__).resolve().with_name('reasonix_android_tools.py')

    def android_capabilities(self):
        script=self.android_tools_script
        if not script.exists():return {'available':False,'error':'reasonix_android_tools.py missing'}
        cp=subprocess.run([sys.executable,str(script),'--capabilities-json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=8)
        if cp.returncode!=0:return {'available':False,'error':(cp.stderr or cp.stdout)[-2000:]}
        try:obj=json.loads(cp.stdout)
        except Exception as e:return {'available':False,'error':'capability parse failed: '+str(e)}
        obj['available']=True;return obj

    def install_android_tools(self):
        script=self.android_tools_script
        if not script.exists():raise RuntimeError('reasonix_android_tools.py missing next to bridge')
        result=self.save_mcp_tool({'name':'android','transport':'stdio','command':sys.executable,'args':[str(script)],'autoStart':True,'replace':True})
        result['capabilities']=self.android_capabilities();result['toolPrefix']='mcp__android__';return result

    @property
    def disabled_skills_root(self): return self.root/'.reasonix-mobile-disabled-skills'
    def skill_detail(self,name):
        if not SAFE_SKILL.fullmatch(name):raise ValueError('bad skill name')
        for enabled,path in [(True,self.skills_root/name/'SKILL.md'),(False,self.disabled_skills_root/name/'SKILL.md')]:
            if path.exists():
                txt=path.read_text(encoding='utf-8',errors='replace')
                body=txt
                if txt.startswith('---'):
                    parts=txt.split('---',2)
                    if len(parts)>=3:body=parts[2].strip()
                return {'name':name,'enabled':enabled,'body':body,'path':str(path.relative_to(self.root)) if enabled else str(path)}
        raise ValueError('skill not found')
    def toggle_skill(self,name,enabled):
        if not SAFE_SKILL.fullmatch(name):raise ValueError('bad skill name')
        src=(self.disabled_skills_root/name/'SKILL.md') if enabled else (self.skills_root/name/'SKILL.md')
        dst=(self.skills_root/name/'SKILL.md') if enabled else (self.disabled_skills_root/name/'SKILL.md')
        if not src.exists():
            # Already in requested state is idempotent.
            current=(self.skills_root/name/'SKILL.md') if enabled else (self.disabled_skills_root/name/'SKILL.md')
            if current.exists():return {'ok':True,'name':name,'enabled':enabled,'changed':False}
            raise ValueError('skill not found')
        dst.parent.mkdir(parents=True,exist_ok=True); atomic_write(dst,src.read_bytes()); src.unlink()
        try:src.parent.rmdir()
        except OSError:pass
        self.start_upstream(self.model)
        return {'ok':True,'name':name,'enabled':enabled,'changed':True,'reloaded':True}
    def toggle_mcp_tool(self,name,enabled):
        if not SAFE_MCP.fullmatch(name):raise ValueError('bad tool server name')
        doc=self._load_mcp_doc();servers=doc.get('mcpServers') or {}
        if name not in servers:raise ValueError('tool server not found')
        spec=servers[name]
        if not isinstance(spec,dict):raise ValueError('invalid tool server')
        spec['auto_start']=bool(enabled); servers[name]=spec;doc['mcpServers']=servers
        atomic_write(self.mcp_path,(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        self.start_upstream(self.model)
        return {'ok':True,'name':name,'enabled':bool(enabled),'reloaded':True}
    def _up_json(self,path,method='GET',body=None,timeout=10):
        payload=b'' if body is None else json.dumps(body,ensure_ascii=False).encode()
        with self.lock:upstream,opener=self.upstream,self.opener
        code,_,raw=self._request_upstream(method,path,payload,'application/json' if body is not None else None,timeout=timeout,upstream=upstream,opener=opener)
        try:data=json.loads(raw.decode('utf-8','replace') or '{}')
        except Exception:data={'raw':raw.decode('utf-8','replace')[:4000]}
        return code,data
    def integration_audit(self):
        sc,st=self._up_json('/mod/status'); cc,contract=self._up_json('/mod/app/contract')
        lc,live=self._up_json('/mod/live/history?limit=500')
        models=self.models();ex=(st.get('execution') or (st.get('power') or {}).get('execution') or {}) if isinstance(st,dict) else {}
        orch=(st.get('orchestrator') or {}) if isinstance(st,dict) else {};budget=(st.get('budget') or {}) if isinstance(st,dict) else {}
        raw=json.dumps(contract,ensure_ascii=False) if isinstance(contract,(dict,list)) else str(contract)

        # The Balance /mod/app/contract is an APK control-plane contract; it is
        # NOT a complete registry of Reasonix built-in tools. v1.5.0 incorrectly
        # used absence from that JSON as proof that read_file/bash/etc were
        # unavailable. Audit the actual selected source tree + compiled binary
        # instead, and keep runtimeVerified separate from registration evidence.
        workspace_path=self.root/'internal'/'tool'/'builtin'/'workspace.go'
        workspace_src=workspace_path.read_text(encoding='utf-8',errors='replace') if workspace_path.exists() else ''
        try: binary_blob=Path(self.binary).read_bytes()
        except Exception: binary_blob=b''
        project_cfg={}
        try:
            cfgp=self.root/'reasonix.toml'
            if cfgp.exists(): project_cfg=tomllib.loads(cfgp.read_text(encoding='utf-8'))
        except Exception: project_cfg={}
        enabled=((project_cfg.get('tools') or {}).get('enabled') if isinstance(project_cfg,dict) else None)
        explicit_enabled=[str(x) for x in enabled] if isinstance(enabled,list) else []
        core_names=['read_file','write_file','edit_file','bash','grep','glob','web_fetch']
        core_tools=[]
        for n in core_names:
            registered=(f'"{n}":' in workspace_src) or (f'`{n}`' in workspace_src)
            in_binary=(n.encode('utf-8') in binary_blob) if binary_blob else False
            config_allows=(not explicit_enabled) or n in explicit_enabled
            core_tools.append({'name':n,'registeredInSource':registered,'presentInBinary':in_binary,'configAllows':config_allows,
                               'contractMentions':n in raw,'availableByStaticEvidence':registered and in_binary and config_allows,
                               'runtimeVerified':False,'builtin':True})

        # Read-only source audit of the currently selected Reasonix tree.
        guard_path=self.root/'internal'/'agent'/'progress_guard.go'
        event_path=self.root/'internal'/'event'/'event.go'
        serve_path=self.root/'internal'/'serve'/'serve.go'
        guard_src=guard_path.read_text(encoding='utf-8',errors='replace') if guard_path.exists() else ''
        event_src=event_path.read_text(encoding='utf-8',errors='replace') if event_path.exists() else ''
        serve_src=serve_path.read_text(encoding='utf-8',errors='replace') if serve_path.exists() else ''
        core_guard={'sourcePresent':bool(guard_src),
          'evidenceAware':all(x in guard_src for x in ['ProgressTracker','ScoreRound','progressNudgeStreak','progressStopStreak']),
          'path':str(guard_path)}
        event_kind=bool(re.search(r'(?m)^\s*Reasoning\s*(?:Kind\s*=\s*iota)?\s*$',event_src)) or 'Reasoning is a thinking-mode reasoning delta' in event_src
        event_payload=bool(re.search(r'(?m)^\s*Reasoning\s+string\b',event_src))
        live_events=self._event_list(live) if lc==200 else []
        live_reasoning=any(self._reasoning_text(e) or any(x in str((e or {}).get('type') or (e or {}).get('kind') or '').lower() for x in ('reason','think','analysis')) for e in live_events if isinstance(e,dict))
        reasoning_transport={'eventReasoning':event_kind and event_payload,
          'eventKindDefined':event_kind,'eventPayloadDefined':event_payload,
          'serveHistoryReasoning':('ReasoningContent' in serve_src and 'json:"reasoning' in serve_src),
          'liveHistoryHttp':lc,'liveReasoningObserved':live_reasoning,
          'historyFallbackEnabled':True,'eventPath':str(event_path),'servePath':str(serve_path)}
        warnings=[]
        if not ex.get('enabled'): warnings.append('Execution Router is disabled/unconfigured; APK Auto cannot honestly claim Flash/Pro auto-routing.')
        if not all(x['availableByStaticEvidence'] for x in core_tools): warnings.append('One or more built-in tools are missing from selected source/binary/config; inspect coreTools.')
        if not reasoning_transport['eventReasoning']: warnings.append('Reasonix typed Reasoning event contract was not detected in the selected source tree.')
        return {'ok':sc==200 and cc==200,'bridge':BRIDGE_VERSION,'upstream':self.upstream,'statusHttp':sc,'contractHttp':cc,
          'modVersion':st.get('modVersion') if isinstance(st,dict) else None,'modRunning':st.get('running') if isinstance(st,dict) else None,
          'execution':ex,'orchestrator':orch,'budget':budget,'model':self.model,'models':models,
          'approvalBridge':{'approve':True,'toolApprovalMode':True,'plan':True},'coreTools':core_tools,
          'coreGuard':core_guard,'reasoningTransport':reasoning_transport,'warnings':warnings}

    BUILTIN_SKILLS={
      'android-developer':('Android разработчик','Разрабатывай Android/Termux/Reasonix проекты. Сначала изучай существующий проект, затем вноси минимальные изменения, запускай подходящие проверки и исправляй реальные ошибки. Не заявляй PASS без проверки.'),
      'debugger':('Отладчик','Воспроизводи ошибку, собирай факты из логов/кода, локализуй первопричину, исправляй только доказанную причину и прогоняй регрессию.'),
      'verifier':('Верификатор','Перед завершением задачи независимо проверь изменённые файлы, сборку/тесты и заявленные результаты. Явно отделяй проверенное от непроверенного.'),
      'web-researcher':('Веб-исследователь','Когда нужен интернет, используй доступные сетевые инструменты, предпочитай первичные источники, сохраняй URL/домены использованных источников и кратко связывай источник с выводом.'),
      'project-architect':('Архитектор проекта','Сначала построй краткую карту существующей архитектуры и зависимостей. Предпочитай совместимые изменения без второго параллельного движка и без дублирования уже существующих систем.')}
    WORKFLOW_SKILLS={
      'rounds':('reasonix-workflow-rounds','Раунды','Перед реализацией сложной задачи кратко сравни два независимых подхода по корректности, стоимости и риску. Выбери один и выполняй только его. Не дублируй одинаковые tool calls ради самого сравнения.'),
      'verify':('reasonix-workflow-verification','Проверка','Перед финальным ответом после изменений выполни подходящие реальные проверки: тесты, сборку, диагностику или чтение результата. Если проверка невозможна, не выдавай PASS — назови конкретный блокер.')}

    def _workflow_paths(self,name):
        spec=self.WORKFLOW_SKILLS.get(name)
        if not spec: raise ValueError('unknown workflow')
        skill=spec[0]
        return skill,self.skills_root/skill/'SKILL.md',self.disabled_skills_root/skill/'SKILL.md'

    def workflow_status(self):
        out={}
        for name in self.WORKFLOW_SKILLS:
            skill,on,off=self._workflow_paths(name)
            out[name]={'name':skill,'enabled':on.exists() and not off.exists(),'installed':on.exists() or off.exists()}
        return {'workflows':out}

    def set_workflows(self,obj):
        if not isinstance(obj,dict): raise ValueError('workflow body must be an object')
        changed=False
        for name,(skill,desc,body) in self.WORKFLOW_SKILLS.items():
            if name not in obj: continue
            if not isinstance(obj[name],bool): raise ValueError(name+' must be boolean')
            target=bool(obj[name]);_,on,off=self._workflow_paths(name)
            if not on.exists() and not off.exists():
                dest=on if target else off;dest.parent.mkdir(parents=True,exist_ok=True)
                fm=['---','name: '+skill,'description: '+json.dumps(desc,ensure_ascii=False),'run-as: inline','invocation: auto','---','',body,'']
                atomic_write(dest,'\n'.join(fm).encode('utf-8'));changed=True
            elif target and off.exists():
                on.parent.mkdir(parents=True,exist_ok=True);atomic_write(on,off.read_bytes());off.unlink();changed=True
                try:off.parent.rmdir()
                except OSError:pass
            elif (not target) and on.exists():
                off.parent.mkdir(parents=True,exist_ok=True);atomic_write(off,on.read_bytes());on.unlink();changed=True
                try:on.parent.rmdir()
                except OSError:pass
        if changed:self.start_upstream(self.model)
        out=self.workflow_status();out.update({'ok':True,'changed':changed,'reloaded':changed});return out
    def install_builtin_pack(self,force=False):
        installed=[];skipped=[]
        for name,(desc,body) in self.BUILTIN_SKILLS.items():
            dest=self.skills_root/name/'SKILL.md'
            disabled=self.disabled_skills_root/name/'SKILL.md'
            # Never overwrite either an enabled or intentionally-disabled user-edited copy unless force=true.
            if (dest.exists() or disabled.exists()) and not force:
                skipped.append(name);continue
            if disabled.exists() and force:
                try: disabled.unlink(); disabled.parent.rmdir()
                except OSError: pass
            self.save_skill({'name':name,'description':desc,'body':body,'runAs':'inline','invocation':'auto'})
            installed.append(name)
        # save_skill writes atomically but deliberately does not restart Reasonix per file.
        # Reload once for the whole pack to keep installation quick and deterministic.
        if installed:self.start_upstream(self.model)
        return {'ok':True,'installed':installed,'skipped':skipped,'reloaded':bool(installed),'baseTools':['read_file','write_file','edit_file','bash','grep','glob','web_fetch','mcp__android__*']}

    @staticmethod
    def _tail(path,limit=12000):
        try:
            data=Path(path).read_bytes()[-limit:]
            return data.decode('utf-8','replace')
        except Exception:return ''

    def diagnostics(self):
        upstream_status=None;upstream_error=''
        try:
            with self.lock: upstream,opener=self.upstream,self.opener
            code,_,body=self._request_upstream('GET','/mod/status',b'',None,timeout=8,upstream=upstream,opener=opener)
            upstream_status={'http':code,'body':body.decode('utf-8','replace')[:4000]}
        except Exception as e:upstream_error=str(e)
        doctor_summary={}
        try:
            d=self.doctor();doctor_summary={'default_model':(d.get('config') or {}).get('default_model'),'providers':[{'name':x.get('name'),'kind':x.get('kind'),'models':x.get('models'),'key_present':x.get('key_present'),'is_default':x.get('is_default')} for x in (d.get('providers') or [])]}
        except Exception as e:doctor_summary={'error':str(e)}
        return {'ok':bool(self.proc and self.proc.poll() is None and upstream_status and upstream_status.get('http')==200),'bridge':BRIDGE_VERSION,'model':self.model,'root':str(self.root),'upstream':self.upstream,'upstreamStatus':upstream_status,'upstreamError':upstream_error,'doctor':doctor_summary,'android':self.android_capabilities(),'reasonixLogTail':self._tail(self.up_log,8000)}



def make_handler(core:MobileCore):
    class H(BaseHTTPRequestHandler):
        server_version='ReasonixMobileBridge/1.5.1'
        def log_message(self,fmt,*args):sys.stderr.write('[bridge] '+fmt%args+'\n')
        def cors(self):
            self.send_header('Access-Control-Allow-Origin','*');self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers','Content-Type, X-Reasonix-Mobile-Token');self.send_header('Access-Control-Max-Age','600')
        def token_ok(self):
            got=self.headers.get('X-Reasonix-Mobile-Token','');return bool(got) and hmac.compare_digest(got,core.token)
        def send_bytes(self,status,headers,body):
            self.send_response(status);self.cors()
            for k,v in headers.items():self.send_header(k,v)
            self.send_header('Content-Length',str(len(body)));self.end_headers()
            if self.command!='HEAD':self.wfile.write(body)
        def send_json(self,status,obj):self.send_bytes(status,{'Content-Type':'application/json','Cache-Control':'no-store'},json.dumps(obj,ensure_ascii=False).encode())
        def read_json(self,limit=MAX_BODY):
            n=int(self.headers.get('Content-Length','0') or 0)
            if n>limit:raise ValueError('request too large')
            return json.loads((self.rfile.read(n) if n else b'{}').decode())
        def do_OPTIONS(self):self.send_response(204);self.cors();self.send_header('Content-Length','0');self.end_headers()
        def do_GET(self):self.handle_api('GET')
        def do_POST(self):self.handle_api('POST')
        def handle_api(self,method):
            u=urlsplit(self.path);path=u.path+(('?'+u.query) if u.query else '')
            if u.path=='/mobile/health':self.send_json(200,{'ok':True,'bridge':BRIDGE_VERSION,'model':core.model,'tokenRequired':True});return
            if not self.token_ok():self.send_bytes(401,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'},b'Unauthorized\n');return
            try:
                if u.path=='/auth/token' and method=='POST':
                    obj=self.read_json(8192);self.send_bytes(204 if hmac.compare_digest(str(obj.get('token','')),core.token) else 401,{'Cache-Control':'no-store'},b'');return
                if u.path=='/mobile/diagnostics' and method=='GET':self.send_json(200,core.diagnostics());return
                if u.path=='/mobile/integration-audit' and method=='GET':self.send_json(200,core.integration_audit());return
                if u.path=='/mobile/builtins/install' and method=='POST':self.send_json(200,core.install_builtin_pack(bool(self.read_json().get('force',False))));return
                if u.path=='/mobile/workflows' and method=='GET':self.send_json(200,core.workflow_status());return
                if u.path=='/mobile/workflows' and method=='POST':self.send_json(200,core.set_workflows(self.read_json()));return
                if u.path=='/mobile/android/capabilities' and method=='GET':self.send_json(200,core.android_capabilities());return
                if u.path=='/mobile/android/install-tools' and method=='POST':self.send_json(200,core.install_android_tools());return
                if u.path=='/mobile/logs' and method=='GET':self.send_json(200,{'bridge':core._tail(core.state/'bridge.log',12000),'reasonix':core._tail(core.up_log,12000)});return
                if u.path=='/mobile/models' and method=='GET':self.send_json(200,core.models());return
                if u.path=='/mobile/model' and method=='POST':
                    obj=self.read_json();self.send_json(200,core.switch_model(str(obj.get('model','')).strip()));return
                if u.path=='/mobile/provider' and method=='POST':self.send_json(200,core.add_provider(self.read_json()));return
                if u.path=='/mobile/projects' and method=='GET':self.send_json(200,core.list_projects());return
                if u.path=='/mobile/projects' and method=='POST':self.send_json(200,core.save_project(self.read_json()));return
                if u.path=='/mobile/projects/delete' and method=='POST':self.send_json(200,core.delete_project(str(self.read_json().get('id','')).strip()));return
                if u.path=='/mobile/system-prompt' and method=='GET':self.send_json(200,core.get_system_prompt());return
                if u.path=='/mobile/system-prompt' and method=='POST':self.send_json(200,core.set_system_prompt(self.read_json(SKILL_MAX+8192)));return
                if u.path=='/mobile/tools' and method=='GET':self.send_json(200,core.list_mcp_tools());return
                if u.path=='/mobile/tools' and method=='POST':self.send_json(200,core.save_mcp_tool(self.read_json()));return
                if u.path=='/mobile/tools/delete' and method=='POST':self.send_json(200,core.delete_mcp_tool(str(self.read_json().get('name','')).strip()));return
                if u.path=='/mobile/tools/toggle' and method=='POST':
                    obj=self.read_json();self.send_json(200,core.toggle_mcp_tool(str(obj.get('name','')).strip(),bool(obj.get('enabled',True))));return
                if u.path=='/mobile/skills' and method=='GET':self.send_json(200,core.list_skills());return
                if u.path=='/mobile/skills' and method=='POST':self.send_json(200,core.save_skill(self.read_json(SKILL_MAX+8192)));return
                if u.path=='/mobile/skills/delete' and method=='POST':self.send_json(200,core.delete_skill(str(self.read_json().get('name','')).strip()));return
                if u.path=='/mobile/skills/toggle' and method=='POST':
                    obj=self.read_json();self.send_json(200,core.toggle_skill(str(obj.get('name','')).strip(),bool(obj.get('enabled',True))));return
                if u.path=='/mobile/skills/detail' and method=='GET':self.send_json(200,core.skill_detail((parse_qs(u.query).get('name') or [''])[0]));return
                if u.path=='/mobile/info' and method=='GET':
                    self.send_json(200,{'model':core.model,'upstream':core.upstream,'root':str(core.root),'skillsRoot':str(core.skills_root),'androidTools':str(core.android_tools_script),'bridgeVersion':'1.5.1'});return
                n=int(self.headers.get('Content-Length','0') or 0)
                if n>MAX_BODY:self.send_bytes(413,{'Content-Type':'text/plain'},b'Too Large\n');return
                body=self.rfile.read(n) if n else b''
                status,headers,out=core.forward(method,path,body,self.headers.get('Content-Type'));self.send_bytes(status,headers,out)
            except ValueError as e:self.send_json(400,{'error':str(e)})
            except Exception as e:self.send_json(500,{'error':str(e)})
    return H


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--binary',required=True);ap.add_argument('--state',required=True)
    ap.add_argument('--token-file',required=True);ap.add_argument('--model',required=True);ap.add_argument('--addr',default='127.0.0.1:37914');ap.add_argument('--port-file');ap.add_argument('--pid-file')
    a=ap.parse_args();host,port=a.addr.rsplit(':',1)
    if host not in ('127.0.0.1','localhost','::1'): raise SystemExit('mobile bridge must bind loopback only')
    core=MobileCore(a.root,a.binary,a.state,a.token_file,a.model)
    class MobileHTTPServer(ThreadingHTTPServer): daemon_threads=True; allow_reuse_address=True
    srv=MobileHTTPServer((host,int(port)),make_handler(core));actual=f'{srv.server_address[0]}:{srv.server_address[1]}'
    if a.port_file:atomic_write(Path(a.port_file),(actual+'\n').encode('utf-8'),0o600)
    if a.pid_file:atomic_write(Path(a.pid_file),(str(os.getpid())+'\n').encode('utf-8'),0o600)
    print(f'REASONIX_MOBILE_BRIDGE_READY {actual} model={core.model}',flush=True)
    signal.signal(signal.SIGTERM,lambda *_:sys.exit(0));signal.signal(signal.SIGINT,lambda *_:sys.exit(0))
    try:srv.serve_forever()
    finally:core.stop_upstream();srv.server_close()

if __name__=='__main__':main()
