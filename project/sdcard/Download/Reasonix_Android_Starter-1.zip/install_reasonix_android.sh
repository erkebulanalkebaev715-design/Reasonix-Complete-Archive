#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "=== Reasonix Android bootstrap ==="
echo "1) Updating Termux packages..."
pkg update -y
pkg upgrade -y

echo "2) Installing build tools..."
pkg install -y git golang make clang ca-certificates

echo "3) Checking architecture..."
echo "uname -m: $(uname -m)"
echo "ABI: $(getprop ro.product.cpu.abi 2>/dev/null || true)"

SRC="$HOME/src/DeepSeek-Reasonix"
mkdir -p "$HOME/src"

if [ -d "$SRC/.git" ]; then
  echo "4) Updating existing Reasonix source..."
  cd "$SRC"
  git fetch origin
  git checkout main-v2
  git pull --ff-only origin main-v2
else
  echo "4) Cloning Reasonix source..."
  git clone --depth 1 --branch main-v2 https://github.com/esengine/DeepSeek-Reasonix.git "$SRC"
  cd "$SRC"
fi

echo "5) Go version:"
go version

VERSION="$(git describe --tags --always 2>/dev/null || echo android-build)"

echo "6) Building Reasonix CLI for this phone..."
CGO_ENABLED=0 go build \
  -ldflags "-s -w -X main.version=$VERSION" \
  -o "$PREFIX/bin/reasonix" \
  ./cmd/reasonix

chmod +x "$PREFIX/bin/reasonix"

echo "7) Basic launch test..."
reasonix --help >/dev/null
echo "Reasonix launches: OK"

echo "8) Creating a zero-cost test workspace..."
TESTDIR="$HOME/projects/reasonix-test"
mkdir -p "$TESTDIR"
cat > "$TESTDIR/hello.py" <<'EOF'
def add(a, b):
    return a + b

print(add(2, 3))
EOF

echo
echo "=== DONE ==="
echo "Reasonix binary: $PREFIX/bin/reasonix"
echo "Source: $SRC"
echo "Test project: $TESTDIR"
echo
echo "API key is NOT configured and no money is spent."
echo "Next check:"
echo "  reasonix --help"
echo
echo "If your build fails, copy the LAST 30-50 lines of the error to ChatGPT."
