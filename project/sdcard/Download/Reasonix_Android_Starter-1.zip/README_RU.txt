REASONIX + TERMUX — STARTER ДЛЯ ANDROID

Что внутри:
1) install_reasonix_android.sh — автоматическая установка зависимостей,
   скачивание исходников Reasonix main-v2 и сборка прямо на телефоне.
2) TERMUX_DOWNLOAD.txt — официальный источник Termux.

ВАЖНО:
• API DeepSeek пока НЕ нужен.
• Скрипт не тратит деньги на API.
• Reasonix в актуальных релизах не даёт готовый Linux ARM64 APK/Android-бинарник,
  поэтому самый честный вариант — собрать CLI из исходников в Termux.
• Проект Reasonix написан на Go и официально поддерживает сборку CLI из исходников.

КАК ЗАПУСТИТЬ:
1. Установи Termux.
2. Открой Termux.
3. Дай Termux доступ к файлам:
   termux-setup-storage
4. Положи install_reasonix_android.sh в Downloads.
5. Выполни:

   cp ~/storage/downloads/install_reasonix_android.sh ~/
   chmod +x ~/install_reasonix_android.sh
   ~/install_reasonix_android.sh

Если будет ошибка — пришли последние строки ошибки.
