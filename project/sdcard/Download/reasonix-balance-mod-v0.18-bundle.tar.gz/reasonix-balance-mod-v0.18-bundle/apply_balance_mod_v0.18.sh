#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-$HOME/DeepSeek-Reasonix}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/balance_mod_v0.18.patch"
PY_BIN="${PY_BIN:-python3}"

if [[ ! -d "$TARGET/.git" ]]; then
  echo "ERROR: Reasonix git tree not found: $TARGET" >&2
  exit 2
fi
if [[ ! -f "$PATCH" ]]; then
  echo "ERROR: v0.18 patch missing: $PATCH" >&2
  exit 2
fi
command -v "$PY_BIN" >/dev/null 2>&1 || { echo "ERROR: python3 missing" >&2; exit 2; }

cd "$TARGET"

# v0.18 is only for the already-fixed, already-passing v0.17 baseline.
for f in \
  internal/sessioninbox/completion_receipt.go \
  internal/sessioninbox/completion_receipt_test.go \
  internal/sessioninbox/types.go \
  scripts/balance_mod_v017_targeted.sh; do
  [[ -f "$f" ]] || { echo "ERROR: v0.17 baseline file missing: $f" >&2; exit 3; }
done

grep -q 'const SchemaVersion = 3' internal/sessioninbox/types.go || {
  echo "ERROR: v0.17 inbox schema marker missing; refusing v0.18." >&2
  exit 3
}
grep -q 'CommitCompletion' internal/sessioninbox/completion_receipt.go || {
  echo "ERROR: v0.17 completion receipt runtime missing; refusing v0.18." >&2
  exit 3
}
if grep -q 'meta, ok := m.item(id)' internal/sessioninbox/completion_receipt.go; then
  echo "ERROR: unfixed v0.17 unused-meta baseline detected; apply the passed v0.17 hotfix first." >&2
  exit 3
fi
grep -q 's.runID = foreignRunID' internal/sessioninbox/completion_receipt_test.go || {
  echo "ERROR: v0.17 crash-simulation hotfix marker missing; refusing v0.18." >&2
  exit 3
}

if git apply --check "$PATCH"; then
  echo "v0.18 patch apply check: PASS"
  git apply "$PATCH"
elif git apply --reverse --check "$PATCH"; then
  echo "Balance Mod v0.18 is already applied; reverse-apply check: PASS"
else
  echo "ERROR: v0.18 patch does not match this v0.17 tree." >&2
  echo "Refusing force/fuzzy apply." >&2
  exit 4
fi

chmod +x \
  scripts/balance_mod_v018_targeted.sh \
  scripts/balance_mod_v018_rc.sh \
  scripts/balance_mod_smoke_quick_v018.sh \
  scripts/balance_mod_smoke_v018.sh

bash -n scripts/balance_mod_v018_targeted.sh
bash -n scripts/balance_mod_v018_rc.sh
bash -n scripts/balance_mod_smoke_quick_v018.sh
bash -n scripts/balance_mod_smoke_v018.sh

"$PY_BIN" - <<'PY'
import json
from pathlib import Path
p = Path('configs/balance_mod_v018_rc_manifest.json')
data = json.loads(p.read_text(encoding='utf-8'))
assert data['modVersion'] == 'balance-mod-v0.18'
assert data['baseline'] == 'balance-mod-v0.17'
assert data['apkContract'] == 'balance-apk-v1'
assert data['provider']['kind'] == 'mock'
assert data['provider']['apiKeyRequired'] is False
assert data['budget']['hardStop'] is True
assert data['budget']['budgetKzt'] == 1000
assert data['budget']['reservePercent'] == 15
assert data['budget']['proMaxPercent'] == 25
cfg = Path('configs/reasonix.balance.v018.toml').read_text(encoding='utf-8')
for marker in ('default_model = "balance-rc-mock"', 'kind = "mock"', 'model = "smoke"', 'offline = true', 'bash = "off"'):
    assert marker in cfg, marker
PY

if ! git diff --check; then
  echo "ERROR: git diff --check failed after v0.18 apply" >&2
  exit 5
fi

# A successful apply must also be mechanically reversible. This is a check only;
# it does not alter the installed tree.
if ! git apply --reverse --check "$PATCH"; then
  echo "ERROR: v0.18 reverse-apply check failed after installation" >&2
  exit 6
fi

echo "Balance Mod v0.18 applied; reverse-apply + diff checks: PASS"
echo "No Go build/test and no provider/API call was performed by this installer."
echo "Targeted: cd '$TARGET' && PATH=/usr/local/go/bin:\$PATH GOTOOLCHAIN=local ./scripts/balance_mod_v018_targeted.sh"
echo "Quick:    cd '$TARGET' && PATH=/usr/local/go/bin:\$PATH GOTOOLCHAIN=local ./scripts/balance_mod_smoke_quick_v018.sh"
echo "Full:     cd '$TARGET' && PATH=/usr/local/go/bin:\$PATH GOTOOLCHAIN=local ./scripts/balance_mod_smoke_v018.sh"
