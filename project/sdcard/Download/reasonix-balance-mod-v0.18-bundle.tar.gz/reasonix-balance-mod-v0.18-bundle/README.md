# Reasonix Balance Mod v0.18 — Full Offline Prototype / Release Candidate

Required baseline: **v0.17 PASS**, including the v0.17 crash-test hotfixes.

v0.18 is deliberately a **release-candidate integration gate**, not another feature layer.
It freezes one canonical offline runtime config and one RC manifest, bumps the exposed
Balance Mod version to `balance-mod-v0.18`, and proves the existing native Reasonix
systems work together before any APK UI or real provider is introduced.

## What the v0.18 RC gate proves

On one localhost `reasonix serve` instance, with all common provider API-key environment
variables removed:

1. the canonical v0.18 mock config boots;
2. `/mod/status` exposes `balance-mod-v0.18`;
3. a hard 1000 KZT workspace budget with CNY FX is admitted pre-call;
4. `/mod/app/task/start` starts an actual agent turn;
5. the native mock provider drives the real Reasonix tool loop (`read_file` -> `grep`);
6. `/mod/live/history` exposes the observable completion (`OFFLINE_MOCK_PASS`);
7. the hard budget remains below its configured limit.

The RC suite also reruns the already-existing offline prototype, v0.15 stress gate,
v0.16 hard pre-call process gate, and v0.17 crash/replay targeted gate.

This does **not** prove behavior of DeepSeek or any other real network provider.
No DeepSeek/provider API key is read, written, requested, or needed.

## Canonical RC config

- `configs/reasonix.balance.v018.toml` — actual offline Reasonix config used by the RC harness.
- `configs/balance_mod_v018_rc_manifest.json` — machine-readable release expectations for the future APK/backend handoff.

These are test/release fixtures. The installer does not overwrite the user's live
`reasonix.toml` or project profile.

## Install in Debian

```bash
cd ~
cp /sdcard/Download/reasonix-balance-mod-v0.18-bundle.tar.gz .
tar -xzf reasonix-balance-mod-v0.18-bundle.tar.gz
bash reasonix-balance-mod-v0.18-bundle/apply_balance_mod_v0.18.sh ~/DeepSeek-Reasonix
```

The installer performs v0.17 baseline checks, patch apply/reverse-apply checks,
`bash -n`, JSON/TOML fixture sanity checks, and `git diff --check`. It intentionally
does not claim any Go build/test result.

## Test order

Targeted RC integration first:

```bash
cd ~/DeepSeek-Reasonix
PATH=/usr/local/go/bin:$PATH GOTOOLCHAIN=local ./scripts/balance_mod_v018_targeted.sh
```

Expected:

`BALANCE_MOD_V18_TARGETED_PASS`

Then quick regression:

```bash
PATH=/usr/local/go/bin:$PATH GOTOOLCHAIN=local ./scripts/balance_mod_smoke_quick_v018.sh
```

Expected:

`BALANCE_MOD_V18_QUICK_PASS`

Then full regression + RC gate:

```bash
PATH=/usr/local/go/bin:$PATH GOTOOLCHAIN=local ./scripts/balance_mod_smoke_v018.sh
```

Expected final line:

`BALANCE_MOD_V18_SMOKE_PASS`
